{:user {:plugins [[cider/cider-nrepl "0.8.2"]]
        :dependencies [[org.clojure/tools.nrepl "0.2.7"]]}}
;; {:user {:plugins [[cider/cider-nrepl "0.8.2"]
;;                   [refactor-nrepl "0.3.0-SNAPSHOT"]]
;;         :dependencies [[acyclic/squiggly-clojure "0.1.2-SNAPSHOT"]]}}
